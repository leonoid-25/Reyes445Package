#' Play the Fizz Buzz Game!!!
#'
#' This function takes in a positive integer and outputs a vector
#' containing the number from 1 to the input where any number
#' divisible by 3 and 5 is replaced with "FizzBuzz"
#' Any number divisible by only 3 is replaced with "Fizz"
#' Any number divisible by only 5 is replaced with "Buzz"
#'
#'
#'
#' @param N A positive Integer
#' @return a character valued vector of length N
#' @examples
#' FizzBuzz(15)
#' FizzBuzz(30)
#' @export
FizzBuzz <- function(N){
  fizzbuzz = NULL
  library(dplyr)
  for (i in 1:N) {
    ifelse(N <= 0 | round(N, 0) != N | is.character(N), stop("Entry is not a positive integer"),
    fizzbuzz[i] <- case_when(i %% 3 != 0 & i %% 5 != 0 ~ toString(i),
                             i %% 3 == 0 & i %% 5 == 0 ~ 'FizzBuzz',
                             i %% 3 == 0 ~ 'Fizz',
                             i %% 5 == 0 ~ 'Buzz'))
  }
  return(fizzbuzz)
}
