#' Flagstaff Pulliam Airport Weather Data
#'
#' Contains precipitation, snowfall, maximum and minimum temperatures
#' daily from 2015 to 2019 for the Flagstaff Pulliam Airport.
#'
#' Source: https://www.ncdc.noaa.gov
#'
#' @format A data frame with 1719 observations with 5 columns.
#' \describe{
#'    \item{DATE}{Date of weather reading}
#'    \item{PRCP}{Precipitation for the day in inches}
#'    \item{SNOW}{Snow for the day in inches}
#'    \item{TMAX}{Maximum temperature for the day in Fahrenheit}
#'    \item{TMIN}{Minimum temperature for the day in Fahrenheit}
#' }
"Flagstaff_Weather"
