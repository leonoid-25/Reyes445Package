# Check to see if fizz buzz returns expected values in the expected format
test_that('Correct values and format returned', {
  expect_equal(FizzBuzz(3), c("1", "2", "Fizz"))
  expect_equal(length(FizzBuzz(100)), 100)
  expect_error(FizzBuzz(-15), "Entry is not a positive integer")
})
